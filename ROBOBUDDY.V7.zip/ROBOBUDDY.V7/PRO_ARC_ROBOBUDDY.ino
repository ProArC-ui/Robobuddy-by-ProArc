/*
 * ======================================================================================
 * ESP32 Desktop Buddy (RoboBuddy)
 * ======================================================================================
 * Features: OLED expressions and idle sleep, clock, weather, WiFi diagnostics,
 * work timer, daily quote, configurable faces, touch gestures, and buddy.local portal.
 * ======================================================================================
 */

#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ESPmDNS.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <time.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <string.h>

// ---------------- OLED Display Settings ----------------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C // Change to 0x3D if your OLED uses that address
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ---------------- Pin Definitions ----------------------
#define TOUCH_PIN     4    // TTP223 digital touch output (SIG)
#define TOUCH_VCC_PIN 18   // Powers TTP223 VCC directly from GPIO (no breadboard needed)
#define LED_PIN       2    // External LED or onboard blue LED on GPIO 2
#define I2C_SDA       21   // OLED SDA
#define I2C_SCL       22   // OLED SCL

// ---------------- State Management --------------------
enum BuddyMode {
  MODE_EYES = 0,
  MODE_CLOCK,
  MODE_WEATHER,
  MODE_WIFI,
  MODE_TIMER,
  NUM_MODES
};

BuddyMode currentMode = MODE_EYES;
bool apConfigMode = false;

// ---------------- Configuration Storage ---------------
Preferences prefs;
String buddyName   = "RoboBuddy";
String wifiSSID    = "";
String wifiPass    = "";
String weatherKey  = "";
String weatherCity = "London";
float  tzOffsetHr  = 5.5; // e.g. +5.5 for IST, -5 for EST, +1 for CET

// ---------------- Weather Data -------------------------
float currentTemp = 0.0;
String weatherDesc = "No Data";
int currentHumidity = 0;
bool weatherAvailable = false;
unsigned long lastWeatherCheck = 0;
const unsigned long WEATHER_INTERVAL_MS = 15UL * 60UL * 1000UL; // Every 15 min

// ---------------- Web Server for Setup ----------------
WebServer server(80);

// ---------------- Eye Animation Variables -------------
int leftEyeX = 38;
int rightEyeX = 90;
int eyeY = 32;
int eyeWidth = 28;
int eyeHeight = 36;
int eyeRadius = 9;

int pupilOffsetX = 0;
int pupilOffsetY = 0;
int targetOffsetX = 0;
int targetOffsetY = 0;

bool isBlinking = false;
int blinkProgress = 0;
unsigned long nextBlinkTime = 0;
unsigned long nextLookTime = 0;
unsigned long touchStartTime = 0;
bool lastTouchReading = LOW;
unsigned long lastDebounceTime = 0;
const unsigned long DEBOUNCE_DELAY = 50;
const unsigned long LONG_PRESS_MS = 900;
const unsigned long PORTAL_HOLD_MS = 10000;

// Work timer and periodic break reminder (session data resets on reboot).
bool timerRunning = false;
bool timerSessionStarted = false;
unsigned long timerStartedAt = 0;
unsigned long workElapsedMs = 0;
unsigned long lastBreakReminder = 0;
bool breakReminder = false;

// WiFi diagnostics. RSSI is shown as a signal-quality estimate; ESP32 cannot
// reliably report internet throughput without running a separate speed test.
int wifiLatencyMs = -1;
unsigned long lastLatencyCheck = 0;
const unsigned long LATENCY_INTERVAL_MS = 10000;
String eyeMood = "calm";
// Face selection: bits 0-12 are regular expressions, 13 Ignore, 14 DVD bounce.
const char* const faceNames[15] = {"calm", "sleepy", "dancing", "cute", "happy", "excited", "wink", "cool", "love", "puppy", "shy", "sparkle", "giggle", "ignore", "dvd"};
const char* const faceLabels[15] = {"Calm", "Sleepy", "Dancing", "Cute", "Happy", "Excited", "Wink", "Cool", "Love", "Puppy", "Shy", "Sparkle", "Giggle", "Ignore", "DVD corner bounce"};
uint16_t enabledFaceMask = 0x7FFF;
bool faceLocked = false;
uint8_t lockedFaceIndex = 0;
uint8_t faceDurationSeconds = 7;
unsigned long lastUserActivity = 0;
const unsigned long IDLE_SLEEP_MS = 120000UL;
bool buddySleeping = false;
bool buddyDrowsy = false;
bool wakingTouch = false;
bool quotesEnabled = true;
String dailyQuote = "";
String dailyQuoteAuthor = "";
String quoteCacheDate = "";
unsigned long lastQuoteAttempt = 0;
bool pendingTap = false;
unsigned long pendingTapAt = 0;
const unsigned long DOUBLE_TAP_MS = 350;
unsigned long happyReactionUntil = 0;

// NTP Server
const char* ntpServer = "pool.ntp.org";

// ---------------- Function Declarations ---------------
void initDisplay();
void loadSettings();
void saveSettings();
void startSetupPortal();
void connectWiFi();
void syncNTPTime();
void fetchWeather();
void handleTouch();
void drawEyesMode();
void drawClockMode();
void drawWeatherMode();
void drawWifiMode();
void drawTimerMode();
void drawAPMode();
void updateWifiLatency();
void drawSleepingMode();
void drawHalfSleepEyes(unsigned long now);
void drawHappyFace();
void drawHappyEyeArches();
void drawCuteHeart(int x, int y, uint16_t color);
void drawAnimatedBlush(unsigned long now);
void fetchDailyQuote();
void drawQuoteCard(unsigned long pageElapsed);
void drawModeHeader(const char* title, const char* status);

// HTML Web Page for Portal
const char CONFIG_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Desktop Buddy Settings</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 20px; margin: 0; }
    .card { background: #1e293b; max-width: 420px; margin: auto; padding: 24px; border-radius: 12px; box-shadow: 0 4px 14px rgba(0,0,0,0.4); }
    h2 { text-align: center; color: #38bdf8; margin-top: 0; }
    p { color: #94a3b8; font-size: 14px; text-align: center; }
    label { font-size: 13px; font-weight: 600; color: #cbd5e1; display: block; margin-top: 14px; margin-bottom: 4px; }
    input { width: 100%; box-sizing: border-box; padding: 10px 12px; border: 1px solid #334155; border-radius: 6px; background: #0f172a; color: white; font-size: 14px; }
    input:focus { outline: none; border-color: #38bdf8; }
    button { width: 100%; margin-top: 22px; padding: 12px; border: none; background: #0284c7; color: white; font-weight: bold; border-radius: 6px; font-size: 15px; cursor: pointer; }
    button:hover { background: #0369a1; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Desktop Buddy Setup</h2>
    <p>Configure your buddy's personality, WiFi, and Weather API.</p>
    <form action="/save" method="POST">
      <label>Buddy Name</label>
      <input type="text" name="name" value="{{NAME}}" required maxlength="12">
      
      <label>WiFi SSID</label>
      <input type="text" name="ssid" value="{{SSID}}" required>
      
      <label>WiFi Password</label>
      <input type="password" name="pass" value="{{PASS}}">
      
      <label>OpenWeatherMap API Key</label>
      <input type="text" name="weather_key" value="{{WEATHER_KEY}}" placeholder="32-character key">
      
      <label>City Name</label>
      <input type="text" name="city" value="{{CITY}}" placeholder="e.g. London or New York">

      <label>Timezone Offset (Hours, e.g. 5.5, -5, 1)</label>
      <input type="number" step="0.5" name="tz_offset" value="{{TZ_OFFSET}}">

      <label><input type="checkbox" name="quotes" value="on" {{QUOTE_CHECKED}} style="width:auto"> Show daily quote between eye animations</label>

      <h3 style="color:#38bdf8;margin-top:24px">Face animations</h3>
      <label><input type="checkbox" name="face_lock" value="on" {{FACE_LOCKED}} style="width:auto"> Lock Buddy to one face</label>
      <label>Locked face</label>
      <select name="locked_face" style="width:100%;padding:10px;border-radius:6px;background:#0f172a;color:white">
        {{FACE_OPTIONS}}
      </select>
      <label>How long each face appears (seconds)</label>
      <input type="number" name="face_duration" min="1" max="60" value="{{FACE_DURATION}}">
      <p style="text-align:left;margin-bottom:4px">Choose which faces may appear when face lock is off:</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:2px 10px">{{FACE_CHECKBOXES}}</div>

      <button type="submit">Save & Restart Buddy</button>
    </form>
  </div>
</body>
</html>
)rawliteral";

// ======================================================================================
// Setup
// ======================================================================================
void setup() {
  Serial.begin(115200);

  // Power TTP223 directly from GPIO 18 (ideal for direct jumper wire setups without breadboard)
  pinMode(TOUCH_VCC_PIN, OUTPUT);
  digitalWrite(TOUCH_VCC_PIN, HIGH);

  pinMode(TOUCH_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(I2C_SDA, I2C_SCL);
  initDisplay();

  loadSettings();

  // If WiFi credentials are not set, immediately enter AP setup mode
  if (wifiSSID.length() == 0) {
    startSetupPortal();
  } else {
    connectWiFi();
    if (WiFi.status() == WL_CONNECTED) {
      syncNTPTime();
      fetchWeather();
    }
  }

  nextBlinkTime = millis() + random(1500, 4000);
  nextLookTime = millis() + random(2000, 5000);
  lastUserActivity = millis();
}

// ======================================================================================
// Main Loop
// ======================================================================================
void loop() {
  if (apConfigMode) {
    server.handleClient();
    drawAPMode();
    delay(20);
    return;
  }

  handleTouch();

  if (!buddySleeping && currentMode == MODE_EYES && millis() - lastUserActivity >= IDLE_SLEEP_MS) {
    buddyDrowsy = true;
    if (millis() - lastUserActivity >= IDLE_SLEEP_MS + 18000UL) buddySleeping = true;
  }

  if (WiFi.status() == WL_CONNECTED && millis() - lastLatencyCheck >= LATENCY_INTERVAL_MS) {
    updateWifiLatency();
  }

  if (quotesEnabled && WiFi.status() == WL_CONNECTED) {
    struct tm quoteTime;
    if (getLocalTime(&quoteTime, 0)) {
      char today[11];
      strftime(today, sizeof(today), "%Y-%m-%d", &quoteTime);
      if (quoteCacheDate != String(today) && millis() - lastQuoteAttempt > 60000UL) fetchDailyQuote();
    } else if (dailyQuote.length() == 0 && millis() - lastQuoteAttempt > 60000UL) {
      fetchDailyQuote();
    }
  }

  // Periodic weather update if connected
  if (WiFi.status() == WL_CONNECTED && (millis() - lastWeatherCheck > WEATHER_INTERVAL_MS || lastWeatherCheck == 0)) {
    fetchWeather();
    lastWeatherCheck = millis();
  }

  // Render current mode
  display.clearDisplay();
  if (buddySleeping) {
    drawSleepingMode();
  } else switch (currentMode) {
    case MODE_EYES:
      drawEyesMode();
      break;
    case MODE_CLOCK:
      drawClockMode();
      break;
    case MODE_WEATHER:
      drawWeatherMode();
      break;
    case MODE_WIFI:
      drawWifiMode();
      break;
    case MODE_TIMER:
      drawTimerMode();
      break;
    default:
      currentMode = MODE_EYES;
      break;
  }
  display.display();
  delay(25); // ~40 FPS refresh
}

// ======================================================================================
// Display Initialization & Splash
// ======================================================================================
void initDisplay() {
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed!"));
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(20, 20);
  display.println(F("Desktop Buddy"));
  display.setCursor(28, 35);
  display.println(F("Booting up..."));
  display.display();
  delay(1200);
}

// ======================================================================================
// Persistent Preferences (NVS Flash)
// ======================================================================================
void loadSettings() {
  prefs.begin("buddy", true);
  buddyName   = prefs.getString("name", "RoboBuddy");
  wifiSSID    = prefs.getString("ssid", "");
  wifiPass    = prefs.getString("pass", "");
  weatherKey  = prefs.getString("w_key", "");
  weatherCity = prefs.getString("w_city", "London");
  tzOffsetHr  = prefs.getFloat("tz_offset", 5.5);
  quotesEnabled = prefs.getBool("quotes", true);
  dailyQuote = prefs.getString("quote", "");
  dailyQuoteAuthor = prefs.getString("quote_author", "");
  quoteCacheDate = prefs.getString("quote_date", "");
  enabledFaceMask = prefs.getUShort("face_mask", 0x7FFF);
  faceLocked = prefs.getBool("face_lock", false);
  lockedFaceIndex = prefs.getUChar("locked_face", 0);
  faceDurationSeconds = prefs.getUChar("face_secs", 7);
  if (lockedFaceIndex >= 15) lockedFaceIndex = 0;
  if (faceDurationSeconds < 1 || faceDurationSeconds > 60) faceDurationSeconds = 7;
  prefs.end();

  Serial.println(F("[Config] Loaded settings from flash:"));
  Serial.print(F("Name: ")); Serial.println(buddyName);
  Serial.print(F("SSID: ")); Serial.println(wifiSSID);
  Serial.print(F("City: ")); Serial.println(weatherCity);
}

void saveSettings() {
  prefs.begin("buddy", false);
  prefs.putString("name", buddyName);
  prefs.putString("ssid", wifiSSID);
  prefs.putString("pass", wifiPass);
  prefs.putString("w_key", weatherKey);
  prefs.putString("w_city", weatherCity);
  prefs.putFloat("tz_offset", tzOffsetHr);
  prefs.putBool("quotes", quotesEnabled);
  prefs.putUShort("face_mask", enabledFaceMask);
  prefs.putBool("face_lock", faceLocked);
  prefs.putUChar("locked_face", lockedFaceIndex);
  prefs.putUChar("face_secs", faceDurationSeconds);
  prefs.end();
  Serial.println(F("[Config] Settings saved to flash."));
}

// ======================================================================================
// Web Setup Portal (SoftAP Mode)
// ======================================================================================
void startSetupPortal() {
  apConfigMode = true;
  digitalWrite(LED_PIN, HIGH); // Steady LED in AP mode

  IPAddress apIP(192, 168, 4, 1);
  IPAddress netMsk(255, 255, 255, 0);

  WiFi.mode(WIFI_AP);
  WiFi.softAP("ESP32-Buddy-Setup");
  WiFi.softAPConfig(apIP, apIP, netMsk);
  MDNS.end();
  bool mdnsStarted = MDNS.begin("buddy");
  if (mdnsStarted) MDNS.addService("http", "tcp", 80);

  Serial.println(F("[Portal] SoftAP started: ESP32-Buddy-Setup"));
  Serial.println(F("[Portal] IP: 192.168.4.1"));
  Serial.println(F("[Portal] Try http://buddy.local (or 192.168.4.1)"));

  server.on("/", HTTP_GET, []() {
    String html = FPSTR(CONFIG_HTML);
    html.replace("{{NAME}}", buddyName);
    html.replace("{{SSID}}", wifiSSID);
    html.replace("{{PASS}}", wifiPass);
    html.replace("{{WEATHER_KEY}}", weatherKey);
    html.replace("{{CITY}}", weatherCity);
    html.replace("{{TZ_OFFSET}}", String(tzOffsetHr, 1));
    html.replace("{{QUOTE_CHECKED}}", quotesEnabled ? "checked" : "");
    html.replace("{{FACE_LOCKED}}", faceLocked ? "checked" : "");
    html.replace("{{FACE_DURATION}}", String(faceDurationSeconds));
    String options, checkboxes;
    for (int i = 0; i < 15; i++) {
      options += "<option value='" + String(i) + "'" + (i == lockedFaceIndex ? " selected" : "") + ">" + faceLabels[i] + "</option>";
      checkboxes += "<label style='display:flex;align-items:center;gap:6px;margin:5px 0'><input style='width:auto' type='checkbox' name='face_" + String(faceNames[i]) + "' value='on'" + ((enabledFaceMask & (1U << i)) ? " checked" : "") + ">" + faceLabels[i] + "</label>";
    }
    html.replace("{{FACE_OPTIONS}}", options);
    html.replace("{{FACE_CHECKBOXES}}", checkboxes);
    server.send(200, "text/html", html);
  });

  server.on("/save", HTTP_POST, []() {
    if (server.hasArg("name")) buddyName = server.arg("name");
    if (server.hasArg("ssid")) wifiSSID = server.arg("ssid");
    if (server.hasArg("pass")) wifiPass = server.arg("pass");
    if (server.hasArg("weather_key")) weatherKey = server.arg("weather_key");
    if (server.hasArg("city")) weatherCity = server.arg("city");
    if (server.hasArg("tz_offset")) tzOffsetHr = server.arg("tz_offset").toFloat();
    quotesEnabled = server.hasArg("quotes");
    faceLocked = server.hasArg("face_lock");
    if (server.hasArg("locked_face")) lockedFaceIndex = constrain(server.arg("locked_face").toInt(), 0, 14);
    if (server.hasArg("face_duration")) faceDurationSeconds = constrain(server.arg("face_duration").toInt(), 1, 60);
    enabledFaceMask = 0;
    for (int i = 0; i < 15; i++) {
      if (server.hasArg(String("face_") + faceNames[i])) enabledFaceMask |= (1U << i);
    }
    if (enabledFaceMask == 0) enabledFaceMask = 1U; // keep Calm as a safe fallback

    saveSettings();

    String resp = "<html><body style='font-family:sans-serif;background:#0f172a;color:#f8fafc;padding:30px;text-align:center;'>";
    resp += "<h2>Settings Saved!</h2><p>Restarting your buddy now...</p></body></html>";
    server.send(200, "text/html", resp);
    delay(1000);
    ESP.restart();
  });

  server.begin();
}

// ======================================================================================
// WiFi Connection
// ======================================================================================
void connectWiFi() {
  if (wifiSSID.length() == 0) return;

  display.clearDisplay();
  display.setCursor(10, 20);
  display.println(F("Connecting WiFi..."));
  display.setCursor(10, 35);
  display.println(wifiSSID);
  display.display();

  WiFi.mode(WIFI_STA);
  WiFi.begin(wifiSSID.c_str(), wifiPass.c_str());

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 25) {
    delay(400);
    digitalWrite(LED_PIN, !digitalRead(LED_PIN)); // Flash LED while connecting
    attempts++;
  }

  digitalWrite(LED_PIN, LOW);

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(F("[WiFi] Connected successfully!"));
    Serial.print(F("[WiFi] IP Address: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("[WiFi] Failed to connect! Running in offline mode."));
  }
}

// ======================================================================================
// NTP Clock Sync
// ======================================================================================
void syncNTPTime() {
  long gmtOffset_sec = (long)(tzOffsetHr * 3600);
  configTime(gmtOffset_sec, 0, ntpServer);
  Serial.println(F("[NTP] Requesting time sync..."));
}

// ======================================================================================
// Weather API Fetch (OpenWeatherMap)
// ======================================================================================
void fetchWeather() {
  if (weatherKey.length() == 0 || weatherCity.length() == 0 || WiFi.status() != WL_CONNECTED) {
    return;
  }

  HTTPClient http;
  WiFiClientSecure secureClient;
  secureClient.setInsecure();
  String cityQuery = weatherCity;
  cityQuery.replace(" ", "%20");
  String url = "https://api.openweathermap.org/data/2.5/weather?q=" + cityQuery +
               "&units=metric&appid=" + weatherKey;

  http.begin(secureClient, url);
  int httpCode = http.GET();

  if (httpCode == HTTP_CODE_OK) {
    StaticJsonDocument<128> filter;
    filter["main"]["temp"] = true;
    filter["main"]["humidity"] = true;
    filter["weather"][0]["main"] = true;
    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(
      doc, http.getStream(), DeserializationOption::Filter(filter));

    if (!error) {
      currentTemp = doc["main"]["temp"] | 0.0;
      currentHumidity = doc["main"]["humidity"] | 0;
      const char* desc = doc["weather"][0]["main"] | "Clear";
      weatherDesc = String(desc);
      weatherAvailable = true;
      Serial.printf("[Weather] %s: %.1f C, %s, %d%%\n", weatherCity.c_str(), currentTemp, weatherDesc.c_str(), currentHumidity);
    } else {
      Serial.printf("[Weather] JSON error: %s\n", error.c_str());
    }
  } else {
    Serial.printf("[Weather] HTTP error: %d\n", httpCode);
  }
  http.end();
}

// ======================================================================================
// Touch Sensor Handling
// ======================================================================================
void handleTouch() {
  int reading = digitalRead(TOUCH_PIN);

  // Debounce check
  if (reading != lastTouchReading) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > DEBOUNCE_DELAY) {
    if (reading == HIGH) {
      if (touchStartTime == 0) {
        bool wasAsleep = buddySleeping || buddyDrowsy;
        touchStartTime = millis();
        lastUserActivity = millis();
        buddyDrowsy = false;
        buddySleeping = false;
        if (wasAsleep) wakingTouch = true;
        digitalWrite(LED_PIN, HIGH); // LED reacts to touch
      }

      // Hold for 10 seconds to open the WiFi/setup portal.
      if ((millis() - touchStartTime) >= PORTAL_HOLD_MS && !apConfigMode) {
        for (int i = 0; i < 4; i++) {
          digitalWrite(LED_PIN, LOW); delay(80);
          digitalWrite(LED_PIN, HIGH); delay(80);
        }
        startSetupPortal();
        return;
      }
    } else {
      if (touchStartTime > 0) {
        unsigned long touchDuration = millis() - touchStartTime;
        digitalWrite(LED_PIN, LOW);
        touchStartTime = 0;

        if (wakingTouch) {
          // The wake touch only wakes the buddy; it does not trigger a mode action.
          wakingTouch = false;
        } else if (currentMode == MODE_TIMER) {
          if (timerRunning && touchDuration < LONG_PRESS_MS) {
            workElapsedMs += millis() - timerStartedAt;
            timerRunning = false;
            digitalWrite(LED_PIN, LOW);
          } else if (!timerRunning && touchDuration >= LONG_PRESS_MS) {
            if (timerSessionStarted) {
              currentMode = MODE_EYES;
              timerSessionStarted = false;
              workElapsedMs = 0;
              lastBreakReminder = 0;
              breakReminder = false;
            } else {
              timerRunning = true;
              timerSessionStarted = true;
              timerStartedAt = millis();
              breakReminder = false;
              digitalWrite(LED_PIN, HIGH);
            }
          } else if (timerRunning && touchDuration >= LONG_PRESS_MS) {
            // Long hold while running pauses and exits the active timer.
            workElapsedMs += millis() - timerStartedAt;
            timerRunning = false;
            timerSessionStarted = false;
            currentMode = MODE_EYES;
            workElapsedMs = 0;
            lastBreakReminder = 0;
            breakReminder = false;
            digitalWrite(LED_PIN, LOW);
          } else if (!timerRunning && touchDuration < LONG_PRESS_MS) {
            // A tap after stopping exits and clears this timer session.
            currentMode = MODE_EYES;
            timerSessionStarted = false;
            workElapsedMs = 0;
            lastBreakReminder = 0;
            breakReminder = false;
          }
        } else if (touchDuration < LONG_PRESS_MS) {
          if (pendingTap && millis() - pendingTapAt <= DOUBLE_TAP_MS) {
            pendingTap = false;
            happyReactionUntil = millis() + 5000UL;
            currentMode = MODE_EYES;
          } else {
            if (pendingTap) {
              currentMode = (BuddyMode)((currentMode + 1) % NUM_MODES);
            }
            pendingTap = true;
            pendingTapAt = millis();
          }
        }
      }
    }
  }

  // Delay a single tap briefly so a second tap can form a double-tap gesture.
  if (pendingTap && touchStartTime == 0 && reading == LOW && millis() - pendingTapAt > DOUBLE_TAP_MS) {
    pendingTap = false;
    currentMode = (BuddyMode)((currentMode + 1) % NUM_MODES);
    Serial.print(F("[Mode] Switched to: "));
    Serial.println(currentMode);
  }

  lastTouchReading = reading;
}

// ======================================================================================
// Mode 1: Expressive Animated Eyes
// ======================================================================================
void drawSingleEye(int centerX, int centerY, int w, int h, int r, int pX, int pY, int blinkHeight, int pupilSize) {
  if (blinkHeight <= 2) {
    // Eye completely closed: horizontal slit line
    display.drawLine(centerX - w / 2, centerY, centerX + w / 2, centerY, SSD1306_WHITE);
    return;
  }

  // Draw eye outline / filled eye socket
  int currentH = blinkHeight;
  int topY = centerY - currentH / 2;
  display.fillRoundRect(centerX - w / 2, topY, w, currentH, r, SSD1306_WHITE);

  // Pupil effect
  if (currentH > 10) {
    int pupilX = centerX + pX;
    int pupilY = centerY + pY;

    // Constrain pupil inside eye boundaries
    pupilX = constrain(pupilX, centerX - w / 2 + 5, centerX + w / 2 - 5);
    pupilY = constrain(pupilY, topY + 4, topY + currentH - 4);

    display.fillCircle(pupilX, pupilY, pupilSize / 2, SSD1306_BLACK);
  }
}

void drawEyesMode() {
  unsigned long now = millis();

  // Cycle subtle moods so the buddy feels more expressive while idle.
  static unsigned long moodUntil = 0;
  static int moodIndex = 0;
  static bool wasDoubleTapHappy = false;
  if (now < happyReactionUntil) {
    eyeMood = "excited";
    wasDoubleTapHappy = true;
  } else {
    if (wasDoubleTapHappy) { moodUntil = now; wasDoubleTapHappy = false; }
  }
  if (now >= happyReactionUntil && now > moodUntil) {
    if (faceLocked) {
      eyeMood = faceNames[lockedFaceIndex];
    } else {
      int pick = random(0, 100);
      int rareIndex = (pick < 3) ? 13 : ((pick < 5) ? 14 : -1);
      if (rareIndex >= 0 && (enabledFaceMask & (1U << rareIndex))) {
        eyeMood = faceNames[rareIndex];
      } else {
        bool found = false;
        for (int tries = 0; tries < 13; tries++) {
          int candidate = moodIndex++ % 13;
          if (enabledFaceMask & (1U << candidate)) {
            eyeMood = faceNames[candidate];
            found = true;
            break;
          }
        }
        // If only a rare face is enabled, still show an enabled face.
        if (!found) {
          eyeMood = (enabledFaceMask & (1U << 13)) ? faceNames[13] : faceNames[14];
        }
      }
    }
    moodUntil = now + (unsigned long)faceDurationSeconds * 1000UL;
  }

  static unsigned long eyesShownSince = 0;
  static unsigned long quoteShownSince = 0;
  static bool quoteShowing = false;
  if (eyesShownSince == 0) eyesShownSince = now;
  if (touchStartTime == 0 && quotesEnabled && dailyQuote.length() > 0) {
    int quoteLines = (dailyQuote.length() + 20) / 21;
    int pageCount = (quoteLines + 1 + 3) / 4; // include author line
    unsigned long quoteDuration = (unsigned long)pageCount * 4000UL;
    if (!quoteShowing && now - eyesShownSince >= 20000UL) {
      quoteShowing = true;
      quoteShownSince = now;
    }
    if (quoteShowing) {
      unsigned long elapsed = now - quoteShownSince;
      if (elapsed < quoteDuration) {
        drawQuoteCard(elapsed);
        return;
      }
      quoteShowing = false;
      eyesShownSince = now;
    }
  } else {
    eyesShownSince = now;
    quoteShowing = false;
  }

  // Touch reaction: happy squinty curved eyes (^ ^)
  if (touchStartTime > 0) {
    drawHappyFace();
    return;
  }

  // Idle transition: half-lidded for a moment, then full sleep with Zzz.
  if (buddySleeping) { drawSleepingMode(); return; }
  if (buddyDrowsy) { drawHalfSleepEyes(now); return; }

  // Random gaze movement
  if (now > nextLookTime) {
    targetOffsetX = random(-7, 8);
    targetOffsetY = random(-4, 5);
    nextLookTime = now + random(1800, 4500);
  }

  // Smooth gaze interpolation
  if (pupilOffsetX < targetOffsetX) pupilOffsetX++;
  else if (pupilOffsetX > targetOffsetX) pupilOffsetX--;
  if (pupilOffsetY < targetOffsetY) pupilOffsetY++;
  else if (pupilOffsetY > targetOffsetY) pupilOffsetY--;

  // Random blink logic
  int currentHeight = eyeHeight;
  if (!isBlinking && now > nextBlinkTime) {
    isBlinking = true;
    blinkProgress = 0;
  }

  if (isBlinking) {
    blinkProgress += 6;
    if (blinkProgress <= eyeHeight) {
      currentHeight = eyeHeight - blinkProgress;
    } else if (blinkProgress <= eyeHeight * 2) {
      currentHeight = blinkProgress - eyeHeight;
    } else {
      isBlinking = false;
      currentHeight = eyeHeight;
      nextBlinkTime = now + random(2500, 6000);
    }
  }

  int leftEyeY = eyeY;
  int rightEyeY = eyeY;
  int leftEyePosX = leftEyeX;
  int rightEyePosX = rightEyeX;
  int leftPupilX = pupilOffsetX;
  int rightPupilX = pupilOffsetX;
  int moodPupilY = pupilOffsetY;
  int renderHeight = currentHeight;
  if (eyeMood == "dancing") {
    int bounce = (now / 180UL) % 2 ? 3 : -3;
    leftEyeY += bounce;
    rightEyeY -= bounce;
  } else if (eyeMood == "excited") {
    renderHeight = 42;
    moodPupilY = -5;
  } else if (eyeMood == "cute") {
    leftPupilX = -3;
    rightPupilX = 3;
    moodPupilY = -3;
  } else if (eyeMood == "puppy") {
    leftPupilX = -2; rightPupilX = 2; moodPupilY = 2; renderHeight = 42;
  } else if (eyeMood == "shy") {
    leftPupilX = 5; rightPupilX = -5; moodPupilY = 5;
  } else if (eyeMood == "sparkle") {
    renderHeight = 42; moodPupilY = -2;
  } else if (eyeMood == "cool") {
    // The narrowed eyes and brows shift subtly so Cool stays animated.
    int coolFrame = (now / 420UL) % 4;
    renderHeight = (coolFrame == 1) ? 27 : ((coolFrame == 3) ? 32 : 30);
    leftPupilX = (coolFrame < 2) ? 5 : -3;
    rightPupilX = (coolFrame < 2) ? 5 : -3;
    moodPupilY = (coolFrame == 2) ? 1 : 3;
  }
  if (eyeMood == "ignore") { leftPupilX = 8; rightPupilX = 8; moodPupilY = -6; }
  if (eyeMood == "dvd") {
    static int bx = 14, by = 12, vx = 2, vy = 1;
    bx += vx; by += vy;
    if (bx < 8 || bx > 38) vx = -vx;
    if (by < 8 || by > 22) vy = -vy;
    leftEyePosX = bx; rightEyePosX = bx + 60;
    leftEyeY = by + 16; rightEyeY = by + 16;
  }
  if (eyeMood == "happy" || eyeMood == "giggle") {
    drawHappyEyeArches();
    drawAnimatedBlush(now);
    if (eyeMood == "giggle") {
      display.drawLine(57, 47, 64, 52, SSD1306_WHITE);
      display.drawLine(64, 52, 71, 47, SSD1306_WHITE);
    }
    return;
  }
  int pupilSize = (eyeMood == "cute" || eyeMood == "puppy" || eyeMood == "sparkle") ? 13 : 10;
  drawSingleEye(leftEyePosX, leftEyeY, eyeWidth, eyeHeight, eyeRadius, leftPupilX, moodPupilY, renderHeight, pupilSize);
  drawSingleEye(rightEyePosX, rightEyeY, eyeWidth, eyeHeight, eyeRadius, rightPupilX, moodPupilY, renderHeight, pupilSize);
  if (eyeMood == "sleepy") {
    display.fillRect(leftEyeX - 14, eyeY - 18, 28, 16, SSD1306_BLACK);
    display.fillRect(rightEyeX - 14, eyeY - 18, 28, 16, SSD1306_BLACK);
    display.drawFastHLine(leftEyeX - 14, eyeY - 2, 28, SSD1306_WHITE);
    display.drawFastHLine(rightEyeX - 14, eyeY - 2, 28, SSD1306_WHITE);
  } else if (eyeMood == "dancing") {
    int bounce = (now / 180UL) % 2 ? 3 : -3;
    display.drawPixel(18, 16 + bounce, SSD1306_WHITE);
    display.drawPixel(108, 16 - bounce, SSD1306_WHITE);
  } else if (eyeMood == "cute") {
    drawCuteHeart(leftEyeX + leftPupilX, eyeY + moodPupilY, SSD1306_BLACK);
    drawCuteHeart(rightEyeX + rightPupilX, eyeY + moodPupilY, SSD1306_BLACK);
    // Cat ears, attentive gaze, and a gentle animated blush.
    display.drawLine(leftEyeX - 10, 17, leftEyeX - 7, 9, SSD1306_WHITE);
    display.drawLine(leftEyeX - 7, 9, leftEyeX - 2, 17, SSD1306_WHITE);
    display.drawLine(rightEyeX + 2, 17, rightEyeX + 7, 9, SSD1306_WHITE);
    display.drawLine(rightEyeX + 7, 9, rightEyeX + 10, 17, SSD1306_WHITE);
    drawAnimatedBlush(now);
  } else if (eyeMood == "wink") {
    display.fillRect(leftEyeX - 14, eyeY - 18, 28, 18, SSD1306_BLACK);
    display.drawFastHLine(leftEyeX - 14, eyeY, 28, SSD1306_WHITE);
    display.drawLine(57, 45, 64, 49, SSD1306_WHITE);
    display.drawLine(64, 49, 71, 45, SSD1306_WHITE);
    drawAnimatedBlush(now);
  } else if (eyeMood == "excited") {
    display.drawLine(leftEyeX - 10, eyeY - 18, leftEyeX + 10, eyeY - 18, SSD1306_BLACK);
    display.drawLine(rightEyeX - 10, eyeY - 18, rightEyeX + 10, eyeY - 18, SSD1306_BLACK);
    display.drawPixel(18, 14, SSD1306_WHITE);
    display.drawPixel(108, 14, SSD1306_WHITE);
  } else if (eyeMood == "cool") {
    // Relaxed narrowed eyes with angled brows and a sideways glance.
    int browLift = (now / 420UL) % 4 == 1 ? 2 : 0;
    display.drawLine(leftEyeX - 11, eyeY - 20 - browLift, leftEyeX + 10, eyeY - 17, SSD1306_WHITE);
    display.drawLine(rightEyeX - 10, eyeY - 17, rightEyeX + 11, eyeY - 20 - browLift, SSD1306_WHITE);
  } else if (eyeMood == "love") {
    drawCuteHeart(leftEyeX, eyeY, SSD1306_BLACK);
    drawCuteHeart(rightEyeX, eyeY, SSD1306_BLACK);
    drawAnimatedBlush(now);
  } else if (eyeMood == "ignore") {
    // Hold a clear upper-right corner glance; no extra mouth or center mark.
  } else if (eyeMood == "puppy") {
    drawAnimatedBlush(now);
    display.drawLine(58, 49, 64, 53, SSD1306_WHITE);
    display.drawLine(64, 53, 70, 49, SSD1306_WHITE);
  } else if (eyeMood == "shy") {
    drawAnimatedBlush(now);
    display.drawLine(59, 50, 64, 52, SSD1306_WHITE);
    display.drawLine(64, 52, 69, 50, SSD1306_WHITE);
  } else if (eyeMood == "sparkle") {
    drawAnimatedBlush(now);
    display.drawPixel(leftEyeX - 3, eyeY - 3, SSD1306_WHITE);
    display.drawPixel(leftEyeX + 3, eyeY + 2, SSD1306_WHITE);
    display.drawPixel(rightEyeX - 3, eyeY + 2, SSD1306_WHITE);
    display.drawPixel(rightEyeX + 3, eyeY - 3, SSD1306_WHITE);
  } else if (eyeMood == "dvd") {
    // Small glints emphasize the playful bouncing eyes.
    display.drawPixel(leftEyePosX - 4, leftEyeY - 17, SSD1306_WHITE);
    display.drawPixel(rightEyePosX + 4, rightEyeY - 17, SSD1306_WHITE);
  }
}

void drawHalfSleepEyes(unsigned long now) {
  drawSingleEye(leftEyeX, eyeY, eyeWidth, eyeHeight, eyeRadius, 0, 0, eyeHeight, 10);
  drawSingleEye(rightEyeX, eyeY, eyeWidth, eyeHeight, eyeRadius, 0, 0, eyeHeight, 10);
  int lid = 10 + (now / 500UL) % 3;
  display.fillRect(leftEyeX - 14, eyeY - 18, 28, lid, SSD1306_BLACK);
  display.fillRect(rightEyeX - 14, eyeY - 18, 28, lid, SSD1306_BLACK);
  display.drawFastHLine(leftEyeX - 14, eyeY - 18 + lid, 28, SSD1306_WHITE);
  display.drawFastHLine(rightEyeX - 14, eyeY - 18 + lid, 28, SSD1306_WHITE);
}

void drawCuteHeart(int x, int y, uint16_t color) {
  display.drawPixel(x - 2, y - 2, color);
  display.drawPixel(x, y - 2, color);
  display.drawPixel(x + 2, y - 2, color);
  display.drawFastHLine(x - 3, y - 1, 7, color);
  display.drawFastHLine(x - 3, y, 7, color);
  display.drawFastHLine(x - 2, y + 1, 5, color);
  display.drawFastHLine(x - 1, y + 2, 3, color);
  display.drawPixel(x, y + 3, color);
}

void drawAnimatedBlush(unsigned long now) {
  int blushWidth = (now / 300UL) % 2 ? 5 : 9;
  display.fillRect(leftEyeX - 22, eyeY + 13, blushWidth, 4, SSD1306_WHITE);
  display.fillRect(rightEyeX + 14, eyeY + 13, blushWidth, 4, SSD1306_WHITE);
}

void drawHappyFace() {
  drawHappyEyeArches();
  drawAnimatedBlush(millis());

  int16_t x1, y1;
  uint16_t w, h;
  display.setTextSize(1);
  display.getTextBounds(buddyName, 0, 0, &x1, &y1, &w, &h);
  display.setCursor((SCREEN_WIDTH - w) / 2, 54);
  display.print(buddyName);
}

void drawHappyEyeArches() {
  // Crescent eyes copied from the supplied sketch's hold reaction.
  display.drawCircle(leftEyeX, eyeY + 4, 14, SSD1306_WHITE);
  display.fillRect(leftEyeX - 16, eyeY + 4, 32, 16, SSD1306_BLACK);
  display.drawCircle(rightEyeX, eyeY + 4, 14, SSD1306_WHITE);
  display.fillRect(rightEyeX - 16, eyeY + 4, 32, 16, SSD1306_BLACK);
}

// Fetch and cache the daily ZenQuotes entry once per local calendar day.
void fetchDailyQuote() {
  if (!quotesEnabled || WiFi.status() != WL_CONNECTED) return;
  lastQuoteAttempt = millis();
  WiFiClientSecure secureClient;
  secureClient.setInsecure(); // ESP32 can fetch without storing a CA certificate.
  HTTPClient http;
  http.setTimeout(6000);
  if (!http.begin(secureClient, "https://zenquotes.io/api/today")) return;
  int code = http.GET();
  if (code == HTTP_CODE_OK) {
    StaticJsonDocument<128> filter;
    filter[0]["q"] = true;
    filter[0]["a"] = true;
    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(
      doc, http.getStream(), DeserializationOption::Filter(filter));
    if (!error && doc.is<JsonArray>() && doc[0]["q"].is<const char*>()) {
      dailyQuote = String((const char*)doc[0]["q"]);
      dailyQuoteAuthor = String((const char*)(doc[0]["a"] | "Unknown"));
      struct tm quoteTime;
      if (getLocalTime(&quoteTime, 0)) {
        char today[11];
        strftime(today, sizeof(today), "%Y-%m-%d", &quoteTime);
        quoteCacheDate = today;
      }
      prefs.begin("buddy", false);
      prefs.putString("quote", dailyQuote);
      prefs.putString("quote_author", dailyQuoteAuthor);
      prefs.putString("quote_date", quoteCacheDate);
      prefs.end();
    }
  }
  http.end();
}

void drawQuoteCard(unsigned long pageElapsed) {
  display.setTextSize(1);
  display.setCursor(0, 0); display.print(F("QUOTE OF THE DAY"));
  display.drawFastHLine(0, 10, SCREEN_WIDTH, SSD1306_WHITE);

  // The quote advances through every 21-character row in four-line pages.
  int quoteLines = (dailyQuote.length() + 20) / 21;
  int page = (int)(pageElapsed / 4000UL);
  for (int row = 0; row < 4; row++) {
    int index = page * 4 + row;
    display.setCursor(0, 12 + row * 10);
    if (index < quoteLines) {
      unsigned int beginAt = index * 21;
      display.print(dailyQuote.substring(beginAt, beginAt + 21));
    } else if (index == quoteLines) {
      display.print("- "); display.print(dailyQuoteAuthor);
    }
  }
  display.setCursor(0, 56); display.print(F("Source: ZenQuotes.io"));
}

void drawSleepingMode() {
  // Fully closed eyes: two quiet flat lines, with a drifting zzZ.
  display.drawFastHLine(leftEyeX - 14, eyeY, 28, SSD1306_WHITE);
  display.drawFastHLine(rightEyeX - 14, eyeY, 28, SSD1306_WHITE);
  static unsigned long lastZ = 0;
  static int zY = 5;
  if (millis() - lastZ > 700UL) { lastZ = millis(); zY = (zY <= 1) ? 8 : zY - 1; }
  display.setTextSize(1);
  display.setCursor(103, zY); display.print(F("zzZ"));
}

// ======================================================================================
// Mode 2: Digital Clock & Date
// ======================================================================================
void drawClockMode() {
  struct tm timeinfo;
  bool gotTime = getLocalTime(&timeinfo);
  drawModeHeader("CLOCK", WiFi.status() == WL_CONNECTED ? "ONLINE" : "OFFLINE");
  if (gotTime) {
    char timeStr[6];
    strftime(timeStr, sizeof(timeStr), "%H:%M", &timeinfo);
    display.setTextSize(3);
    display.setCursor(19, 20);
    display.print(timeStr);
    char seconds[4];
    strftime(seconds, sizeof(seconds), ":%S", &timeinfo);
    display.setTextSize(1);
    display.setCursor(103, 35);
    display.print(seconds);
    char dateStr[18];
    strftime(dateStr, sizeof(dateStr), "%a  %d %b %Y", &timeinfo);
    display.setCursor(20, 52);
    display.print(dateStr);
  } else {
    display.setTextSize(1);
    display.setCursor(20, 27); display.print(F("Waiting for time"));
    display.setCursor(20, 41); display.print(F("Check WiFi / NTP"));
  }
}

// ======================================================================================
// Mode 3: Weather & Buddy Info
// ======================================================================================
void drawWeatherMode() {
  drawModeHeader("WEATHER", WiFi.status() == WL_CONNECTED ? weatherCity.substring(0, 8).c_str() : "OFFLINE");
  if (weatherKey.length() == 0) {
    display.setCursor(8, 25); display.print(F("Weather not set up"));
    display.setCursor(8, 41); display.print(F("Hold 10s for portal"));
    return;
  }
  if (!weatherAvailable) {
    display.setCursor(8, 25); display.print(F("No weather data yet"));
    display.setCursor(8, 41); display.print(F("Check city, key, WiFi"));
    return;
  }
  display.setTextSize(2);
  display.setCursor(5, 18);
  display.print(currentTemp, 1);
  int degreeX = display.getCursorX();
  display.drawCircle(degreeX + 3, 22, 2, SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(degreeX + 7, 19); display.print(F("C"));
  display.setCursor(5, 37); display.print(weatherDesc.substring(0, 18));
  display.drawFastHLine(5, 48, 118, SSD1306_WHITE);
  display.setCursor(5, 54); display.print(F("Humidity ")); display.print(currentHumidity); display.print(F("%"));
  display.drawRoundRect(83, 53, 40, 8, 2, SSD1306_WHITE);
  display.fillRoundRect(85, 55, map(constrain(currentHumidity, 0, 100), 0, 100, 0, 36), 4, 1, SSD1306_WHITE);
}

void drawModeHeader(const char* title, const char* status) {
  display.setTextSize(1);
  display.setCursor(3, 2); display.print(title);
  int statusWidth = strlen(status) * 6;
  display.setCursor(SCREEN_WIDTH - statusWidth - 3, 2); display.print(status);
  display.drawFastHLine(0, 12, SCREEN_WIDTH, SSD1306_WHITE);
}

// ======================================================================================
// AP Setup Mode Screen
// ======================================================================================
void drawAPMode() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(18, 4);
  display.println(F("SETUP PORTAL"));
  display.drawFastHLine(0, 15, SCREEN_WIDTH, SSD1306_WHITE);

  display.setCursor(2, 22);
  display.println(F("1. Connect WiFi:"));
  display.setCursor(10, 32);
  display.println(F("ESP32-Buddy-Setup"));

  display.setCursor(2, 44);
  display.println(F("2. Browser URL:"));
  display.setCursor(10, 54);
  display.println(F("192.168.4.1"));
  display.display();
}

// ======================================================================================
// Mode 4: WiFi diagnostics
// ======================================================================================
void updateWifiLatency() {
  lastLatencyCheck = millis();
  if (WiFi.status() != WL_CONNECTED) { wifiLatencyMs = -1; return; }
  WiFiClient client;
  unsigned long started = millis();
  // A short TCP handshake to the gateway provides a local-network latency estimate.
  if (client.connect(WiFi.gatewayIP(), 80, 500)) {
    wifiLatencyMs = (int)(millis() - started);
    client.stop();
  } else {
    wifiLatencyMs = -1;
  }
}

void drawWifiMode() {
  bool connected = WiFi.status() == WL_CONNECTED;
  drawModeHeader("NETWORK", connected ? "CONNECTED" : "OFFLINE");
  if (WiFi.status() != WL_CONNECTED) {
    display.setCursor(8, 24); display.print(F("No WiFi connection"));
    display.setCursor(8, 39); display.print(F("Hold 10s for portal"));
    display.setCursor(8, 53); display.print(F("Open 192.168.4.1"));
    return;
  }
  int rssi = WiFi.RSSI();
  int quality = constrain(2 * (rssi + 100), 0, 100);
  display.setCursor(3, 15); display.print(F("WiFi: ")); display.print(WiFi.SSID().substring(0, 14));
  display.setCursor(3, 27); display.print(F("IP: ")); display.print(WiFi.localIP());
  display.setCursor(3, 39); display.print(rssi); display.print(F(" dBm"));
  display.drawRoundRect(51, 39, 73, 8, 2, SSD1306_WHITE);
  display.fillRoundRect(53, 41, map(quality, 0, 100, 0, 69), 4, 1, SSD1306_WHITE);
  display.setCursor(3, 53); display.print(F("Gateway latency: "));
  if (wifiLatencyMs >= 0) { display.print(wifiLatencyMs); display.print(F(" ms")); }
  else display.print(F("n/a"));
}

// ======================================================================================
// Mode 5: Work timer
// ======================================================================================
void drawTimerMode() {
  unsigned long total = workElapsedMs + (timerRunning ? millis() - timerStartedAt : 0);
  unsigned long seconds = total / 1000UL;
  char timeText[16];
  snprintf(timeText, sizeof(timeText), "%02lu:%02lu:%02lu", seconds / 3600UL, (seconds / 60UL) % 60UL, seconds % 60UL);
  const char* state = timerRunning ? "RUNNING" : (timerSessionStarted ? "PAUSED" : "READY");
  drawModeHeader("FOCUS TIMER", state);
  display.setTextSize(2);
  display.setCursor(16, 20); display.print(timeText);
  display.setTextSize(1);
  display.setCursor(0, 45);
  if (timerRunning) display.print(F("Tap: stop timer"));
  else if (timerSessionStarted) display.print(F("Hold: exit and reset"));
  else display.print(F("Hold: start working"));

  // Remind the user to stretch after each 50 minutes of tracked work.
  if (total >= 50UL * 60UL * 1000UL && total / (50UL * 60UL * 1000UL) > lastBreakReminder) {
    lastBreakReminder = total / (50UL * 60UL * 1000UL);
    breakReminder = true;
  }
  if (breakReminder) { display.setCursor(0, 56); display.print(F("Break time - stretch!")); }
}
