# RoboBuddy ESP32

RoboBuddy is a small desktop companion built around an ESP32 Dev board, a 0.96-inch 128×64 SSD1306 OLED, and a TTP223 touch sensor. It shows animated expressions and includes clock, weather, Wi-Fi, and work-timer screens. Settings are managed through a browser portal.

## Features

- Animated faces: calm, sleepy, dancing, cute, happy, excited, wink, cool, love, puppy, shy, sparkle, and giggle. Ignore and DVD corner-bounce are occasional faces.
- Face settings in the portal: lock one face, enable or disable faces, and set the time each face stays on screen.
- Idle sleep: after two minutes without touch on the eyes screen, Buddy gets drowsy; 18 seconds later it closes its eyes and shows `zzZ`. Touch wakes it.
- Clock with NTP time and a configurable UTC offset.
- Weather from OpenWeatherMap. The city and API key are set in the portal; weather refreshes about every 15 minutes.
- Wi-Fi information: network name, local IP address, signal estimate, and gateway latency. The latency is a local gateway check, not an internet speed test.
- Work timer with a break reminder after each 50 minutes of tracked work. The session resets when you exit it.
- Optional daily quote from ZenQuotes. Quotes need Wi-Fi and can be switched off in the portal.
- Setup portal available at `buddy.local` when mDNS resolution works; `192.168.4.1` is the fallback address.

## Parts and wiring

| Part | Pin / connection |
| --- | --- |
| OLED GND | ESP32 GND |
| OLED VCC | ESP32 3V3 |
| OLED SDA | GPIO 21 |
| OLED SCL | GPIO 22 |
| TTP223 GND | ESP32 GND |
| TTP223 SIG / OUT | GPIO 4 |
| TTP223 VCC | GPIO 18, powered by the sketch |
| Optional LED | GPIO 2 (onboard LED on some ESP32 boards) |

The display address is set to `0x3C`. If your OLED uses `0x3D`, change `SCREEN_ADDRESS` near the top of the sketch. The touch code expects a momentary TTP223 output: HIGH while touched and LOW when released. If you power the TTP223 from 3V3 instead of GPIO 18, change or remove the `TOUCH_VCC_PIN` power setup so the module is not powered from two sources.

## Arduino IDE setup

1. Install ESP32 board support and select **ESP32 Dev Module**.
2. Install these libraries through Library Manager:
   - **Adafruit SSD1306**
   - **Adafruit GFX Library**
   - **ArduinoJson**
3. Open `PRO_ARC_BUDDY.ino`, select the ESP32 board and its serial port, then upload.

The sketch uses ESP32 core libraries for Wi-Fi, the web server, mDNS, preferences storage, HTTPS, and time synchronization.

## First Wi-Fi setup

If no Wi-Fi network is saved, Buddy starts its setup access point automatically. Otherwise, hold the touch sensor for **10 seconds** from any display screen to open setup.

1. Connect your phone or computer to **ESP32-Buddy-Setup**. It is an open access point and does not provide internet access; stay connected if your device warns you.
2. Open `http://192.168.4.1`. You can also try `http://buddy.local` if your device supports mDNS on the setup network.
3. Enter Wi-Fi details and any optional settings, then save. Buddy restarts with the new settings.

The portal lets you configure the Buddy name, Wi-Fi, weather API key and city, timezone offset, daily quote toggle, and face behavior.

## Touch controls

- **Tap:** cycle through Eyes → Clock → Weather → Network → Work Timer. A short delay distinguishes a single tap from a double tap.
- **Double-tap:** return to Eyes and trigger a brief excited reaction.
- **Hold for 10 seconds:** open the setup portal.
- **Eyes screen:** holding the sensor shows Buddy's happy face and name; touching also wakes it from sleep.
- **Work Timer:** hold to start; tap while running to stop. After stopping, tap or hold to exit and reset the session. A hold while running exits and resets.

## Notes

- Weather requires an OpenWeatherMap API key. Without one, the Weather screen explains that setup is needed.
- Quotes are fetched over HTTPS from the public ZenQuotes daily endpoint and cached in ESP32 preferences. The feed requires Wi-Fi and an internet connection.
- Wi-Fi signal percentage is an estimate based on RSSI. Gateway latency checks the local router and does not measure internet throughput.
- The timezone setting is a fixed UTC offset; daylight-saving changes are not applied automatically.
